<?php
include 'ip.php';
header('Location: login.html');
exit
?>

# BlackEye Python
BlackEye Phishing Kit 32 Templates + 1 Customizable

**USE FOR EDUCATIONAL PURPOSES ONLY**

![alt text](https://image.prntscr.com/image/Ly8QtJxBSFKiMMcD1qrpeg.png)

Converted from https://github.com/thelinuxchoice/blackeye

Uses Site Templates From BlackEye but you can host with a custom sub-domain to Serveo.

Requires PHP and SSH to be installed.
